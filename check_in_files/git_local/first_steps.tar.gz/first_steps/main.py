if True:
  print('You need to edit this file (main.py) and remove/deactivate this if statement')
  quit()

print('Success! main.py is working')
