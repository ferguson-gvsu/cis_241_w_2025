print('Hello, my name is Dr. Ferg')
