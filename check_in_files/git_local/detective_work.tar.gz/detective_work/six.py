def create_assignment(pl_link):
  # Not actually coding these out, sorry
  pass

def grade_assigment(pl_link):
  # Not actually coding these out, sorry
  pass

def create_autograder(pl_link):
  # Not actually coding these out, sorry
  # Haha jk I broke it
  pass
