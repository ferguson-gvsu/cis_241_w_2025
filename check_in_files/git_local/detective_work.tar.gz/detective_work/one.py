def fib(x):
  if x <= 1: 
    return 1
  return fib(x - 1) + fib(x - 2)

def factorial(x):
  if x == 1:
    return 1
  return x * factorial(x - 1)

def cube(x):
  return x * x * x
