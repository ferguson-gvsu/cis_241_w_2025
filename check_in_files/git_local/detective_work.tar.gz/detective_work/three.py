def throw_pokeball(target):
  # Not actually coding these out, sorry
  pass

def apply_damage(target, move):
  # Not actually coding these out, sorry
  pass

def evolve(target):
  # Not actually coding these out, sorry
  pass

def calc_ivs(target):
  # Not actually coding these out, sorry
  pass
