def take_attendance(roster):
  # Not actually coding these out, sorry
  pass

def announce_quiz(roster):
  # Not actually coding these out, sorry
  pass

def curve_exam(exam):
  # Not actually coding these out, sorry
  pass

