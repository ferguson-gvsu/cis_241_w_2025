def create_stefan(workshop):
  # Not actually coding these out, sorry
  pass

def add_flames_to_stefan(workshop, chair):
  # Not actually coding these out, sorry
  pass

def add_more_legs(workshop, chair):
  # Not actually coding these out, sorry
  pass
