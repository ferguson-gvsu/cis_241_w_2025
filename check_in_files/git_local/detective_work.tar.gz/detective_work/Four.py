def apply_selection(pop):
  # Not actually coding these out, sorry
  pass

def apply_mutation(pop):
  # Not actually coding these out, sorry
  pass

def apply_crossover(pop):
  # Not actually coding these out, sorry
  pass

def track_phylogeny(pop):
  # Not actually coding these out, sorry
  pass
